-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: rentsense
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `addresses`
--

DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `addresses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cian_id` bigint DEFAULT NULL,
  `county` varchar(255) DEFAULT NULL,
  `district` varchar(255) DEFAULT NULL,
  `street` varchar(255) DEFAULT NULL,
  `house` varchar(255) DEFAULT NULL,
  `metro` varchar(255) DEFAULT NULL,
  `travel_type` varchar(255) DEFAULT NULL,
  `travel_time` int DEFAULT NULL,
  `address` json DEFAULT NULL,
  `coordinates` json DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ix_addresses_district` (`district`),
  KEY `ix_addresses_cian_id` (`cian_id`),
  KEY `ix_addresses_street` (`street`),
  KEY `ix_addresses_county` (`county`),
  CONSTRAINT `addresses_ibfk_1` FOREIGN KEY (`cian_id`) REFERENCES `offers` (`cian_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `addresses`
--

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `developers`
--

DROP TABLE IF EXISTS `developers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `developers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cian_id` bigint DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `review_count` int DEFAULT NULL,
  `total_rate` decimal(2,1) DEFAULT NULL,
  `buildings_count` int DEFAULT NULL,
  `foundation_year` int DEFAULT NULL,
  `is_reliable` tinyint(1) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ix_developers_cian_id` (`cian_id`),
  CONSTRAINT `developers_ibfk_1` FOREIGN KEY (`cian_id`) REFERENCES `offers` (`cian_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `developers`
--

LOCK TABLES `developers` WRITE;
/*!40000 ALTER TABLE `developers` DISABLE KEYS */;
/*!40000 ALTER TABLE `developers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `offers`
--

DROP TABLE IF EXISTS `offers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `offers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cian_id` bigint NOT NULL,
  `price` decimal(15,2) NOT NULL,
  `category` varchar(255) DEFAULT NULL,
  `views_count` int DEFAULT NULL,
  `photos_count` int DEFAULT NULL,
  `floor_number` int DEFAULT NULL,
  `floors_count` int DEFAULT NULL,
  `publication_at` int DEFAULT NULL,
  `price_changes` json DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_offers_cian_id` (`cian_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `offers`
--

LOCK TABLES `offers` WRITE;
/*!40000 ALTER TABLE `offers` DISABLE KEYS */;
/*!40000 ALTER TABLE `offers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `offers_details`
--

DROP TABLE IF EXISTS `offers_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `offers_details` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cian_id` bigint DEFAULT NULL,
  `agent_name` varchar(255) DEFAULT NULL,
  `deal_type` varchar(255) DEFAULT NULL,
  `flat_type` varchar(255) DEFAULT NULL,
  `sale_type` varchar(255) DEFAULT NULL,
  `is_duplicate` tinyint(1) DEFAULT NULL,
  `description` text,
  `payment_period` varchar(50) DEFAULT NULL,
  `lease_term_type` varchar(50) DEFAULT NULL,
  `deposit` decimal(11,2) DEFAULT NULL,
  `prepay_months` int DEFAULT NULL,
  `utilities_included` tinyint(1) DEFAULT NULL,
  `client_fee` int DEFAULT NULL,
  `agent_fee` int DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ix_offers_details_cian_id` (`cian_id`),
  CONSTRAINT `offers_details_ibfk_1` FOREIGN KEY (`cian_id`) REFERENCES `offers` (`cian_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `offers_details`
--

LOCK TABLES `offers_details` WRITE;
/*!40000 ALTER TABLE `offers_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `offers_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `realty_details`
--

DROP TABLE IF EXISTS `realty_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `realty_details` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cian_id` bigint DEFAULT NULL,
  `realty_type` varchar(255) DEFAULT NULL,
  `project_type` varchar(255) DEFAULT NULL,
  `heat_type` varchar(255) DEFAULT NULL,
  `gas_type` varchar(255) DEFAULT NULL,
  `is_apartment` tinyint(1) DEFAULT NULL,
  `is_penthouse` tinyint(1) DEFAULT NULL,
  `is_mortgage_allowed` tinyint(1) DEFAULT NULL,
  `is_premium` tinyint(1) DEFAULT NULL,
  `is_emergency` tinyint(1) DEFAULT NULL,
  `renovation_programm` tinyint(1) DEFAULT NULL,
  `finish_date` json DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ix_realty_details_realty_type` (`realty_type`),
  KEY `ix_realty_details_cian_id` (`cian_id`),
  CONSTRAINT `realty_details_ibfk_1` FOREIGN KEY (`cian_id`) REFERENCES `offers` (`cian_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `realty_details`
--

LOCK TABLES `realty_details` WRITE;
/*!40000 ALTER TABLE `realty_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `realty_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `realty_inside`
--

DROP TABLE IF EXISTS `realty_inside`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `realty_inside` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cian_id` bigint DEFAULT NULL,
  `repair_type` varchar(255) DEFAULT NULL,
  `total_area` decimal(11,2) DEFAULT NULL,
  `living_area` decimal(11,2) DEFAULT NULL,
  `kitchen_area` decimal(11,2) DEFAULT NULL,
  `ceiling_height` decimal(11,2) DEFAULT NULL,
  `balconies` int DEFAULT NULL,
  `loggias` int DEFAULT NULL,
  `rooms_count` int DEFAULT NULL,
  `separated_wc` int DEFAULT NULL,
  `combined_wc` int DEFAULT NULL,
  `windows_view` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ix_realty_inside_repair_type` (`repair_type`),
  KEY `ix_realty_inside_cian_id` (`cian_id`),
  KEY `ix_realty_inside_total_area` (`total_area`),
  CONSTRAINT `realty_inside_ibfk_1` FOREIGN KEY (`cian_id`) REFERENCES `offers` (`cian_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `realty_inside`
--

LOCK TABLES `realty_inside` WRITE;
/*!40000 ALTER TABLE `realty_inside` DISABLE KEYS */;
/*!40000 ALTER TABLE `realty_inside` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `realty_outside`
--

DROP TABLE IF EXISTS `realty_outside`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `realty_outside` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cian_id` bigint DEFAULT NULL,
  `build_year` int DEFAULT NULL,
  `entrances` int DEFAULT NULL,
  `material_type` varchar(255) DEFAULT NULL,
  `parking_type` varchar(255) DEFAULT NULL,
  `garbage_chute` tinyint(1) DEFAULT NULL,
  `lifts_count` int DEFAULT NULL,
  `passenger_lifts` int DEFAULT NULL,
  `cargo_lifts` int DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ix_realty_outside_cian_id` (`cian_id`),
  KEY `ix_realty_outside_build_year` (`build_year`),
  CONSTRAINT `realty_outside_ibfk_1` FOREIGN KEY (`cian_id`) REFERENCES `offers` (`cian_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `realty_outside`
--

LOCK TABLES `realty_outside` WRITE;
/*!40000 ALTER TABLE `realty_outside` DISABLE KEYS */;
/*!40000 ALTER TABLE `realty_outside` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-09  4:03:29
